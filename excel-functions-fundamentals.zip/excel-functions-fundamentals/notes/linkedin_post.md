# LinkedIn Post – Task 6: Excel & Functions Fundamentals

## Post text (copy-paste)

📊 Day 6 of my Data Analytics internship at Veda Technology – and Excel is officially my new best friend!

Today's task: Excel & Functions Fundamentals. I built a workbook with 318 live formulas on a 60-order retail dataset to practise the formulas analysts use every day.

Here's what I covered 👇

🔎 Lookups – VLOOKUP, INDEX/MATCH, XLOOKUP (and why INDEX/MATCH can look left!)
🧠 Logic – IF, nested IF, AND/OR, IFERROR
➕ Conditional aggregation – SUMIFS, COUNTIFS, AVERAGEIFS with named ranges
✂️ Text cleaning – TRIM, UPPER, LEFT, RIGHT, MID, SUBSTITUTE, FIND
⚠️ Edge cases – blank cells, numbers stored as text, hidden trailing spaces, missing keys

💡 My biggest lesson: most "broken" formulas are really dirty data. A single trailing space made a perfect VLOOKUP fail – wrapping the key in TRIM fixed it instantly. 🙌

✅ Bonus: I added a reconciliation check so my regional totals always match the grand total (49,889.93 ✔).

Interview-ready answers I wrote down:
• SUMIF vs SUMIFS → one condition vs many
• XLOOKUP vs VLOOKUP → any direction, built-in "not found", no fragile column numbers
• INDEX/MATCH vs VLOOKUP → look left + survives column changes

🔗 Full workbook, screenshots and detailed README on GitHub: [PASTE YOUR REPO LINK HERE]

Thank you Veda Technology for the hands-on learning! 🙏

#Excel #DataAnalytics #DataAnalyst #VLOOKUP #XLOOKUP #SUMIFS #LearningInPublic #VedaTechnology #InternshipJourney #MicrosoftExcel #GoogleSheets #DataSkills

---

## Photos to attach (in this order, max 5–6 look best)

| Order | File in `screenshots/` | Why |
|---|---|---|
| 1 (cover) | `05_conditional_agg.png` | Best visual: results table + regional summary with OK check |
| 2 | `03_lookups.png` | Shows VLOOKUP / INDEX-MATCH / XLOOKUP side by side |
| 3 | `07_edge_cases.png` | Naive vs robust formulas – shows depth of thinking |
| 4 | `06_text_functions.png` | Before/after text cleaning |
| 5 | `08_formula_notes.png` | When-to-use guide + interview answers |

Optional extra: a screenshot of your own GitHub repo page (README rendered) as the last image.

## Tagging tips

* Tag **Veda Technology** company page.
* Add your mentor / supervisor if you want visibility.
* Post the GitHub link in the post body (as above) and again as the first comment.

## First comment (copy-paste)

👉 Repo: [PASTE YOUR REPO LINK HERE]
Open to feedback – which Excel function should I master next: Pivot Tables, Power Query or dynamic arrays? 👇
